﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hangman
{
    public partial class FormAyarlar : Form
    {
        public FormAyarlar()
        {
            InitializeComponent();
        }

        private void FormAyarlar_Load(object sender, EventArgs e)
        {
            cmbKategori.Items.AddRange(new string[] { "Teknoloji", "Edebiyat", "Ev", "Tümü" });
            cmbZorluk.Items.AddRange(new string[] { "Kolay", "Orta", "Zor", "Tümü" });
            cmbMod.Items.AddRange(new string[] { "Gercek Adam", "Cop Adam", "Balon Patlatma" });

            cmbKategori.SelectedIndex = 0;
            cmbZorluk.SelectedIndex = 0;
            nudSure.Value = 20;
            cmbMod.SelectedIndex = 0;
        }



        private void btnKaydet_Click_1(object sender, EventArgs e)
        {
            Form1.SecilenKategori = cmbKategori.SelectedItem.ToString();
            Form1.SecilenZorluk = cmbZorluk.SelectedItem.ToString();
            Form1.SecilenMod = cmbMod.SelectedItem.ToString();
            Form1.SecilenSure = (int)nudSure.Value;

            MessageBox.Show("Ayarlar başarıyla kaydedildi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }

    }
}
