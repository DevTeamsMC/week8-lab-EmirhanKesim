﻿namespace hangman
{
    partial class FormAyarlar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            cmbKategori = new ComboBox();
            cmbZorluk = new ComboBox();
            nudSure = new NumericUpDown();
            btnKaydet = new Button();
            cmbMod = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            Ayarlar = new GroupBox();
            ((System.ComponentModel.ISupportInitialize)nudSure).BeginInit();
            Ayarlar.SuspendLayout();
            SuspendLayout();
            // 
            // cmbKategori
            // 
            cmbKategori.FormattingEnabled = true;
            cmbKategori.Location = new Point(19, 86);
            cmbKategori.Margin = new Padding(3, 2, 3, 2);
            cmbKategori.Name = "cmbKategori";
            cmbKategori.Size = new Size(133, 23);
            cmbKategori.TabIndex = 0;
            // 
            // cmbZorluk
            // 
            cmbZorluk.FormattingEnabled = true;
            cmbZorluk.Location = new Point(19, 132);
            cmbZorluk.Margin = new Padding(3, 2, 3, 2);
            cmbZorluk.Name = "cmbZorluk";
            cmbZorluk.Size = new Size(133, 23);
            cmbZorluk.TabIndex = 1;
            // 
            // nudSure
            // 
            nudSure.Location = new Point(19, 40);
            nudSure.Margin = new Padding(3, 2, 3, 2);
            nudSure.Name = "nudSure";
            nudSure.Size = new Size(133, 23);
            nudSure.TabIndex = 2;
            // 
            // btnKaydet
            // 
            btnKaydet.Location = new Point(19, 218);
            btnKaydet.Margin = new Padding(3, 2, 3, 2);
            btnKaydet.Name = "btnKaydet";
            btnKaydet.Size = new Size(131, 32);
            btnKaydet.TabIndex = 3;
            btnKaydet.Text = "Kaydet";
            btnKaydet.UseVisualStyleBackColor = true;
            btnKaydet.Click += btnKaydet_Click_1;
            // 
            // cmbMod
            // 
            cmbMod.FormattingEnabled = true;
            cmbMod.Location = new Point(19, 181);
            cmbMod.Margin = new Padding(3, 2, 3, 2);
            cmbMod.Name = "cmbMod";
            cmbMod.Size = new Size(133, 23);
            cmbMod.TabIndex = 4;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.Location = new Point(19, 19);
            label1.Name = "label1";
            label1.Size = new Size(39, 19);
            label1.TabIndex = 5;
            label1.Text = "Süre:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.Location = new Point(19, 65);
            label2.Name = "label2";
            label2.Size = new Size(63, 19);
            label2.TabIndex = 6;
            label2.Text = "Kategori:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F);
            label3.Location = new Point(19, 161);
            label3.Name = "label3";
            label3.Size = new Size(84, 19);
            label3.TabIndex = 7;
            label3.Text = "Görsel Mod:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 10F);
            label4.Location = new Point(19, 111);
            label4.Name = "label4";
            label4.Size = new Size(48, 19);
            label4.TabIndex = 8;
            label4.Text = "Zorluk";
            // 
            // Ayarlar
            // 
            Ayarlar.Controls.Add(label4);
            Ayarlar.Controls.Add(label3);
            Ayarlar.Controls.Add(label2);
            Ayarlar.Controls.Add(label1);
            Ayarlar.Controls.Add(cmbMod);
            Ayarlar.Controls.Add(btnKaydet);
            Ayarlar.Controls.Add(nudSure);
            Ayarlar.Controls.Add(cmbZorluk);
            Ayarlar.Controls.Add(cmbKategori);
            Ayarlar.Location = new Point(173, 19);
            Ayarlar.Name = "Ayarlar";
            Ayarlar.Size = new Size(169, 272);
            Ayarlar.TabIndex = 9;
            Ayarlar.TabStop = false;
            Ayarlar.Text = "Ayarlar";
            // 
            // FormAyarlar
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(502, 338);
            Controls.Add(Ayarlar);
            Margin = new Padding(3, 2, 3, 2);
            Name = "FormAyarlar";
            Text = "FormAyarlar";
            Load += FormAyarlar_Load;
            ((System.ComponentModel.ISupportInitialize)nudSure).EndInit();
            Ayarlar.ResumeLayout(false);
            Ayarlar.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private ComboBox cmbKategori;
        private ComboBox cmbZorluk;
        private NumericUpDown nudSure;
        private Button btnKaydet;
        private ComboBox cmbMod;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private GroupBox Ayarlar;
    }
}