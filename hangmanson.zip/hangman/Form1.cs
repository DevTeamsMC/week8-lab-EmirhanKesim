namespace hangman
{
    public partial class Form1 : Form
    {
        public static string SecilenKategori = "Genel K�lt�r";
        public static string SecilenZorluk = "Kolay";
        public static string SecilenMod = "Gercek Adam";
        public static int SecilenSure = 20;


        public Form1()
        {
            InitializeComponent();

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            Form2 gameForm = new Form2();
            gameForm.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnAyarlar_Click(object sender, EventArgs e)
        {
            FormAyarlar ayarForm = new FormAyarlar();
            ayarForm.ShowDialog();
        }
    }
}
