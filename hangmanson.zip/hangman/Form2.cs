﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hangman
{
    public partial class Form2 : Form
    {
        private string[] words = { "bilgisayar", "telefon", "kitap", "kalem", "masa" };
        private string[] hints = { "Elektronik cihaz", "İletişim aracı", "Okunacak şey", "Yazı yazma aracı", "Üzerine bir şeyler koyulan eşya" };
        private string selectedWord = "";
        private string hint = "";
        private int score = 100;
        private int wrongGuesses = 0;
        private List<char> guessedLetters = new List<char>();
        private List<char> wrongLetters = new List<char>();
        private System.Windows.Forms.Timer gameTimer;
        private int timeLeft = 20;

        public Form2()
        {
            InitializeComponent();
            lblHint.Visible = false;
            InitializeTimer();
            this.Shown += (s, e) => StartNewGame();
        }


        private void InitializeTimer()
        {
            gameTimer = new System.Windows.Forms.Timer();
            gameTimer.Interval = 1000;
            gameTimer.Tick += GameTimer_Tick;

            Label lblTimer = new Label();
            lblTimer.Name = "lblTimer";
            lblTimer.Text = $"Kalan Süre: {timeLeft} saniye";
            lblTimer.AutoSize = true;
            lblTimer.Location = new Point(400, 20);
            lblTimer.Font = new Font(lblTimer.Font, FontStyle.Bold);
            this.Controls.Add(lblTimer);
        }

        private void GameTimer_Tick(object sender, EventArgs e)
        {
            timeLeft--;

            var timerLabel = this.Controls.Find("lblTimer", true).FirstOrDefault() as Label;
            if (timerLabel != null)
            {
                timerLabel.Text = $"Kalan Süre: {timeLeft} saniye";

                if (timeLeft <= 5)
                {
                    timerLabel.ForeColor = Color.Red;
                }
            }

            if (timeLeft <= 0)
            {
                gameTimer.Stop();
                BackColor = Color.LightCoral;
                DialogResult rGameOver = MessageBox.Show($"Süre doldu! Game Over. Doğru kelime: {selectedWord}", "Süre Bitti", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                if (rGameOver == DialogResult.OK)
                {
                    Form1 mainForm = new Form1();
                    this.Close();
                    mainForm.Show();
                }
                    

            }
        }
        private class Soru
        {
            public string Kelime { get; set; }
            public string Ipucu { get; set; }
            public string Kategori { get; set; }
            public string Zorluk { get; set; }
        }

        private List<Soru> SoruYukle(string kategori, string zorluk)
        {
            List<Soru> sorular = new List<Soru>();

            string dosyaYolu = Path.Combine(Application.StartupPath, "sorular.txt");
            if (!File.Exists(dosyaYolu))
            {
                MessageBox.Show("sorular.txt dosyası bulunamadı.");
                return sorular;
            }

            foreach (string satir in File.ReadAllLines(dosyaYolu))
            {
                if (string.IsNullOrWhiteSpace(satir)) continue;

                string[] parcalar = satir.Split(';');
                if (parcalar.Length != 4) continue;

                var s = new Soru
                {
                    Kelime = parcalar[0].Trim(),
                    Ipucu = parcalar[1].Trim(),
                    Kategori = parcalar[2].Trim().ToLower(),
                    Zorluk = parcalar[3].Trim().ToLower()
                };

                string kategoriLower = kategori.ToLower();
                string zorlukLower = zorluk.ToLower();

                if ((kategoriLower == "tümü" || s.Kategori == kategoriLower) &&
                    (zorlukLower == "tümü" || s.Zorluk == zorlukLower))
                {
                    sorular.Add(s);
                }

            }

            return sorular;
        }


        private void StartNewGame()
        {
            try
            {
                timeLeft = Form1.SecilenSure;  // Süreyi ayarlardan al
                var timerLabel = this.Controls.Find("lblTimer", true).FirstOrDefault() as Label;
                if (timerLabel != null)
                {
                    timerLabel.Text = $"Kalan Süre: {timeLeft} saniye";
                    timerLabel.ForeColor = SystemColors.ControlText;
                }

                // TXT dosyasından kategori ve zorluk filtresine göre soruları al
                var secilenSorular = SoruYukle(Form1.SecilenKategori, Form1.SecilenZorluk);

                if (secilenSorular.Count == 0)
                {
                    secilenSorular = SoruYukle("Teknoloji", "Kolay");
                    MessageBox.Show(
                        "Ayarlar yapılandırılmadığı için varsayılan seçenekler uygulandı.\n" +
                        "Varsayılan:\n" +
                        "Kategori: Teknoloji\n" +
                        "Zorluk: Kolay\n" +
                        "Mod: Gerçek Adam\n" +
                        "Süre: 20 saniye",
                        "Bilgi",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
                if (secilenSorular.Count == 0)
                {
                    MessageBox.Show("Seçilen kategori ve zorlukta hiç soru bulunamadı!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                    return;
                }

                // Rastgele bir soru seç
                Random rnd = new Random();
                var secilen = secilenSorular[rnd.Next(secilenSorular.Count)];

                selectedWord = secilen.Kelime;
                hint = secilen.Ipucu;

                // Oyun başlangıcı için kalan ayarlar
                score = 100;
                wrongGuesses = 0;
                guessedLetters.Clear();
                wrongLetters.Clear();

                if (lblHint != null) lblHint.Text = "İpucu: " + hint;
                UpdateWordDisplay();
                UpdateScore();
                UpdateHangmanImage();
                BackColor = SystemColors.Control;

                gameTimer.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Oyun başlatılırken hata: {ex.Message}");
            }

        }

        private void UpdateHangmanImage()
        {
            int imageIndex = Math.Clamp(wrongGuesses + 1, 1, 10);
            string prefix = Form1.SecilenMod switch
            {
                "Cop Adam" => "cman",
                "Balon Patlatma" => "pman",
                _ => "man"
            };

            string imageName = $"{prefix}-{imageIndex:00}.jpg";
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string imagePath = Path.Combine(baseDir, "Resources", imageName);

            try
            {
                if (picHangman.Image != null)
                {
                    var oldImage = picHangman.Image;
                    picHangman.Image = null;
                    oldImage.Dispose();
                }

                if (File.Exists(imagePath))
                {
                    using (var tempImage = Image.FromFile(imagePath))
                    {
                        picHangman.Image = new Bitmap(tempImage);
                    }
                }
                else
                {
                    var bmp = new Bitmap(picHangman.Width, picHangman.Height);
                    using (var g = Graphics.FromImage(bmp))
                    {
                        g.Clear(Color.Red);
                    }
                    picHangman.Image = bmp;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Resim yüklenemedi: {ex.Message}\nYol: {imagePath}");
            }
        }

        private void UpdateWordDisplay()
        {
            try
            {
                if (lblWord == null || string.IsNullOrEmpty(selectedWord)) return;

                StringBuilder display = new StringBuilder();
                foreach (char letter in selectedWord)
                {
                    if (guessedLetters.Contains(letter))
                        display.Append(letter + " ");
                    else
                        display.Append("_ ");
                }

                lblWord.Text = display.ToString();

                if (!lblWord.Text.Contains("_"))
                {
                    gameTimer.Stop();
                    BackColor = Color.LightGreen;
                    if (MessageBox.Show($"Tebrikler, kazandınız! Puanınız: {score}") == DialogResult.OK)
                    {
                        Form1 mainForm = new Form1();
                        this.Close();
                        mainForm.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Kelime güncellenirken hata: {ex.Message}");
            }
        }

        private void UpdateScore()
        {
            try
            {
                if (lblScore != null) lblScore.Text = "Puan: " + score;
                if (lblWrongLetters != null) lblWrongLetters.Text = "Yanlış Harfler: " + string.Join(", ", wrongLetters);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Skor güncellenirken hata: {ex.Message}");
            }
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtGuess == null || string.IsNullOrEmpty(selectedWord)) return;

                if (string.IsNullOrEmpty(txtGuess.Text) || txtGuess.Text.Length != 1)
                {
                    MessageBox.Show("Lütfen tek bir harf giriniz.");
                    return;
                }

                char guess = char.ToLower(txtGuess.Text[0]);

                if (!char.IsLetter(guess))
                {
                    MessageBox.Show("Lütfen sadece harf giriniz.");
                    return;
                }

                if (guessedLetters.Contains(guess) || wrongLetters.Contains(guess))
                {
                    MessageBox.Show("Bu harfi zaten denediniz.");
                    return;
                }

                if (selectedWord.ToLower().Contains(char.ToLower(guess)))
                {
                    guessedLetters.Add(guess);
                    UpdateWordDisplay();
                }
                else
                {
                    wrongGuesses++;
                    wrongLetters.Add(guess);
                    score = Math.Max(0, score - 10);
                    UpdateHangmanImage();
                    UpdateScore();

                    if (wrongGuesses >= 10)
                    {
                        gameTimer.Stop();
                        BackColor = Color.LightCoral;
                        
                        if (MessageBox.Show($"Kaybettiniz! Doğru kelime: {selectedWord}") == DialogResult.OK)
                        {
                            Form1 mainForm = new Form1();
                            this.Close();
                            mainForm.Show();
                        }
                        //StartNewGame();
                    }
                }

                txtGuess.Clear();
                txtGuess.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Tahmin işlenirken hata: {ex.Message}");
            }
        }

        private void btnEndGame_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Oyunu sonlandırmak istediğinize emin misiniz?", "Çıkış",
                    MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    gameTimer.Stop();
                    Form1 mainForm = new Form1();
                    mainForm.Show();
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Oyun sonlandırılırken hata: {ex.Message}");
            }
        }

        private void btnHint_Click(object sender, EventArgs e)
        {
            if (lblHint.Visible == false)
                lblHint.Visible = true;
            else
                lblHint.Visible = false;
        }
    }
}
