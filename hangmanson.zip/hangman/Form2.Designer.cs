﻿namespace hangman
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            lblWord = new Label();
            lblHint = new Label();
            lblScore = new Label();
            lblWrongLetters = new Label();
            txtGuess = new TextBox();
            btnGuess = new Button();
            btnEndGame = new Button();
            picHangman = new PictureBox();
            btnHint = new Button();
            lblTimer = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            ((System.ComponentModel.ISupportInitialize)picHangman).BeginInit();
            SuspendLayout();
            // 
            // lblWord
            // 
            lblWord.AutoSize = true;
            lblWord.Font = new Font("Segoe UI", 18F);
            lblWord.Location = new Point(43, 34);
            lblWord.Name = "lblWord";
            lblWord.Size = new Size(92, 32);
            lblWord.TabIndex = 0;
            lblWord.Text = "_ _ _ _ _";
            // 
            // lblHint
            // 
            lblHint.AutoSize = true;
            lblHint.Font = new Font("Segoe UI", 12F);
            lblHint.Location = new Point(43, 79);
            lblHint.Name = "lblHint";
            lblHint.Size = new Size(51, 21);
            lblHint.TabIndex = 1;
            lblHint.Text = "İpucu:";
            // 
            // lblScore
            // 
            lblScore.AutoSize = true;
            lblScore.Font = new Font("Segoe UI", 12F);
            lblScore.Location = new Point(43, 111);
            lblScore.Name = "lblScore";
            lblScore.Size = new Size(79, 21);
            lblScore.TabIndex = 2;
            lblScore.Text = "Puan: 100";
            // 
            // lblWrongLetters
            // 
            lblWrongLetters.AutoSize = true;
            lblWrongLetters.Font = new Font("Segoe UI", 12F);
            lblWrongLetters.Location = new Point(43, 142);
            lblWrongLetters.Name = "lblWrongLetters";
            lblWrongLetters.Size = new Size(105, 21);
            lblWrongLetters.TabIndex = 3;
            lblWrongLetters.Text = "Yanlış Harfler:";
            // 
            // txtGuess
            // 
            txtGuess.Location = new Point(43, 179);
            txtGuess.Name = "txtGuess";
            txtGuess.Size = new Size(144, 23);
            txtGuess.TabIndex = 4;
            // 
            // btnGuess
            // 
            btnGuess.Location = new Point(43, 223);
            btnGuess.Name = "btnGuess";
            btnGuess.Size = new Size(144, 23);
            btnGuess.TabIndex = 5;
            btnGuess.Text = "Tahmin Et";
            btnGuess.UseVisualStyleBackColor = true;
            btnGuess.Click += btnGuess_Click;
            // 
            // btnEndGame
            // 
            btnEndGame.Location = new Point(711, 5);
            btnEndGame.Name = "btnEndGame";
            btnEndGame.Size = new Size(77, 23);
            btnEndGame.TabIndex = 6;
            btnEndGame.Text = "Oyunu Bitir";
            btnEndGame.UseVisualStyleBackColor = true;
            btnEndGame.Click += btnEndGame_Click;
            // 
            // picHangman
            // 
            picHangman.Location = new Point(-3, -12);
            picHangman.Name = "picHangman";
            picHangman.Size = new Size(835, 495);
            picHangman.SizeMode = PictureBoxSizeMode.StretchImage;
            picHangman.TabIndex = 7;
            picHangman.TabStop = false;
            // 
            // btnHint
            // 
            btnHint.Location = new Point(43, 401);
            btnHint.Name = "btnHint";
            btnHint.Size = new Size(144, 23);
            btnHint.TabIndex = 8;
            btnHint.Text = "İpucu";
            btnHint.UseVisualStyleBackColor = true;
            btnHint.Click += btnHint_Click;
            // 
            // lblTimer
            // 
            lblTimer.AutoSize = true;
            lblTimer.Font = new Font("Segoe UI", 10F);
            lblTimer.Location = new Point(43, 9);
            lblTimer.Name = "lblTimer";
            lblTimer.Size = new Size(0, 19);
            lblTimer.TabIndex = 9;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblTimer);
            Controls.Add(btnHint);
            Controls.Add(txtGuess);
            Controls.Add(btnEndGame);
            Controls.Add(btnGuess);
            Controls.Add(lblWrongLetters);
            Controls.Add(lblScore);
            Controls.Add(lblHint);
            Controls.Add(lblWord);
            Controls.Add(picHangman);
            Name = "Form2";
            Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)picHangman).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblWord;
        private Label lblHint;
        private Label lblScore;
        private Label lblWrongLetters;
        private TextBox txtGuess;
        private Button btnGuess;
        private Button btnEndGame;
        private PictureBox picHangman;
        private Button btnHint;
        private Label lblTimer;
        private System.Windows.Forms.Timer timer1;
    }
}